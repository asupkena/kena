./cpuminer-ryzen --config=ltncg.json
